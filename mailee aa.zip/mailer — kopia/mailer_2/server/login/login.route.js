const express = require('express');
const router = express.Router();
const loginService = require('./service');

router.post('/api/admin/login', loginService.adminLogin);
router.post('/api/user_login', loginService.userLogin);

module.exports = router;
