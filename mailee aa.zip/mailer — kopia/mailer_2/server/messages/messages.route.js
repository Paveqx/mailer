const express = require('express');
const router = express.Router();
const messageService = require('./service/messages');
const { get } = require('mongoose');

router.get('/', (req, res) => {
  const loggedInUser = req.session.loggedInUser;

  if (loggedInUser) {
    res.send(`Zalogowany użytkownik: ${loggedInUser}`);
  } else {
    res.send('Użytkownik nie jest zalogowany.');
  }
});

router.get('/api/messages', messageService.getMessages);
router.post('/api/messages', messageService.addMessages);
router.delete('/api/messages/:id', messageService.deleteMessages);

module.exports = router;