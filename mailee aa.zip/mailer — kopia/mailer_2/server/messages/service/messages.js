const Messages = require('./../../models/messages');
const jwt = require("jsonwebtoken");

const getMessages = async (req, res) => {
  try {
    const token = req.query.token;
    const decoded = jwt.verify(token, 'user_mailer123');

    if (!decoded) {
      return res.status(200).json({ success: false });
    };

    const user = decoded.email;
    const messages = await Messages.find({ receiver: user });

    return res.status(200).json({ success: true, mails: messages });
  } catch (error) {
    return res.status(500).json({ success: false });
  }
};

const addMessages = async (req, res) => {
  try {
  } catch (error) {
    return res.status(500).json({ success: false });
  }
};

const deleteMessages = async (req, res) => {
  try {
  } catch (error) {
    return res.status(500).json({ success: false });
  }
};

module.exports = {
  getMessages,
  addMessages,
  deleteMessages
};
