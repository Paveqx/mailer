const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  app.use(
    [
      // api pobierajace wszystkich uzytkownikow
      '/api/users',
      // api pobierajace endpoint do logowania dla uzytkownika user.admin === true z pliku server/login/service/login.js
      '/api/user_login',
      '/api/messages'
      
    ],
    createProxyMiddleware({
      target: 'http://localhost:8080',
      changeOrigin: true,
    })
  );
};