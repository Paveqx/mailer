import React, { useState, useEffect } from "react";
import axios from "axios";
import jwtDecode from "jwt-Decode";
import { useNavigate} from "react-router-dom"

const SendMessage = () => {
  const [userInfo, setUserInfo] = useState("");
  const [recipient, setRecipient] = useState("");
  const [content, setContent] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [navigate] = useNavigate();
  
  useEffect(() => {
    const token = sessionStorage.getItem("token");

    if (token) {
      const decodedToken = jwtDecode(token);

      setUserInfo(decodedToken);
    }
  }, []);

  const handleLogout = () => {
    sessionStorage.removeItem("token");
    navigate("/login");
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();

    try {
      const token = sessionStorage.getItem("token");
      const response = await sendMessage(token, recipient, content);

      setSuccessMessage(response.data.message);
      setRecipient("");
      setContent("");
    } catch (error) {
      setErrorMessage(error.response.data.message || "Błąd podczas wysyłania wiadomości");
    }
  };

  const sendMessage = async (token, receiverEmail, messageContent) => {
    try {
      const response = await axios.post("http://localhost:8080/messages/send", {
        receiver: receiverEmail,
        content: messageContent
      }, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });

      console.log('Wiadomość wysłana:', response.data);
      return response.data;
    } catch (error) {
      console.error('Błąd podczas wysyłania wiadomości:', error);
      throw new Error('Błąd podczas wysyłania wiadomości');
    }
  };

  return (
    <div>
      <div className="user-info">
        {userInfo && (
          <p>
            Zalogowany użytkownik:{" "}
            {userInfo.admin ? "Admin" : "Standardowy użytkownik"}
          </p>
        )}
          <button onClick={handleLogout}>Wyloguj</button>{" "}
      </div>
      <h2>Wyślij wiadomość</h2>
      <form onSubmit={handleSendMessage}>
        <label htmlFor="recipient">Odbiorca:</label>
        <input type="email" id="recipient" value={recipient} onChange={(e) => setRecipient(e.target.value)} />

        <label htmlFor="content">Treść wiadomości:</label>
        <textarea id="content" value={content} onChange={(e) => setContent(e.target.value)} />

        <button type="submit">Wyślij wiadomość</button>
      </form>
      {successMessage && <p className="success">{successMessage}</p>}
      {errorMessage && <p className="error">{errorMessage}</p>}
    </div>
  );
};

export default SendMessage;
