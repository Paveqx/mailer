import React, { useState, useEffect } from "react";
import axios from "axios";

const Messages = ({ userId }) => {
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const fetchMessages = async () => {
      try {
        if (userId) {
          const response = await axios.get(`/api/messages?token=${userId}`);
          setMessages(response.data.mails);
        }
      } catch (error) {
        console.error("Błąd podczas pobierania wiadomości:", error);
      }
    };

    fetchMessages();
  }, [userId]);
  const renderMessages = () => {
    return (
      <ul>
        {messages.map((message) => (
          <li key={message._id}>
            <strong>Od:</strong> {message.sender.email}, <strong>Data:</strong>{" "}
            {message.timestamp}
            <br />
            {message.content}
          </li>
        ))}
      </ul>
    );
  };

  return (
    <div>
      <h2>Wiadomości</h2>
      {messages.length > 0 ? renderMessages() : <p>Brak wiadomości</p>}
    </div>
  );
};

export default Messages;
