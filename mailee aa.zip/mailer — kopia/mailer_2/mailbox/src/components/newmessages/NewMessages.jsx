const SendMessage = () => {
    const [recipient, setRecipient] = useState('');
    const [content, setContent] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const usersList = [];
   
    const handleSendMessage = async (e) => {
       e.preventDefault();
       try {
         setSuccessMessage('Wiadomość została wysłana pomyślnie.');
         setErrorMessage('');
       } catch (error) {z
         setErrorMessage('Wystąpił błąd podczas wysyłania wiadomości.');
         setSuccessMessage('');
       }
    };
   
    return (
       <div>
         <h2>Wyślij wiadomość</h2>
         <form onSubmit={handleSendMessage}>
           <label htmlFor="recipient">Odbiorca:</label>
           <select id="recipient" value={recipient} onChange={(e) => setRecipient(e.target.value)}>
             <option value="">Wybierz użytkownika</option>
             {usersList.map((user) => (
               <option key={user._id} value={user._id}>
                 {user.username}
               </option>
             ))}
           </select>
   
           <label htmlFor="content">Treść wiadomości:</label>
           <textarea id="content" value={content} onChange={(e) => setContent(e.target.value)} />
   
           <button type="submit">Wyślij wiadomość</button>
         </form>
         {successMessage && <p className="success">{successMessage}</p>}
         {errorMessage && <p className="error">{errorMessage}</p>}
       </div>
    );
   };
   
   export default SendMessage;